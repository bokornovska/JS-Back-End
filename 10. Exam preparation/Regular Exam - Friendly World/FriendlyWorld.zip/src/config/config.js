exports.SECRET = 'bgekrg45t3htfigeghg9245';
exports.TOKEN_KEY = 'token';